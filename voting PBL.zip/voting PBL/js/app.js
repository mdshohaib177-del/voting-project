console.log("Biometric Voting System Started");

async function registerUser() {
    const name = document.getElementById("name").value.trim();
    const usn = document.getElementById("usn").value.trim();

    if (!name || !usn) {
        alert("Please fill all fields");
        return;
    }

    if (!window.faceCaptureDescriptor) {
        alert("Please capture your face before registering.");
        return;
    }

    const encodingString = faceCaptureDescriptor.join(",");

    const { error } = await db
        .from("user")
        .insert([
            {
                name: name,
                usn: usn,
                face_encoding: encodingString,
                has_voted: false
            }
        ]);

    if (error) {
        console.error(error);
        alert(error.message);
    } else {
        alert("Registration Successful");
        window.location.href = "login.html";
    }
}

async function loginUser() {
    const usn = document.getElementById("loginUsn").value.trim();

    if (!usn) {
        alert("Enter USN");
        return;
    }

    if (!window.faceVerifiedUserId || window.faceVerifiedUserUsn !== usn) {
        alert("Please verify your face before logging in.");
        return;
    }

    localStorage.setItem("userId", window.faceVerifiedUserId);
    alert("Login Successful");
    window.location.href = "voting.html";
}